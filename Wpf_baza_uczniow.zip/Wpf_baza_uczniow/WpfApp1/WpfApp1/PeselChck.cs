﻿using System;

namespace WpfApp1
{
    public static class PeselChck
    {
        public static bool IsValidPesel(string pesel)
        {
            if (pesel.Length != 11 || !CzySameCyfry(pesel))
                return false;

            return SumaKontrolna(pesel);
        }

        private static bool CzySameCyfry(string pesel)
        {
            foreach (char znak in pesel)
            {
                if (!char.IsDigit(znak))
                    return false;
            }
            return true;
        }

        private static bool SumaKontrolna(string pesel)
        {
            int sumaKontrolna = 0;
            int[] mnozniki = {1,3,7,9,1,3,7,9,1,3};

            for (int i = 0; i < 10; i++)
            {
                sumaKontrolna += int.Parse(pesel[i].ToString()) * mnozniki[i];
            }

            int kontrolnaCyfra = 10 - (sumaKontrolna % 10);
            if (kontrolnaCyfra == 10)
                kontrolnaCyfra = 0;

            return kontrolnaCyfra == int.Parse(pesel[10].ToString());
        }
    }
}
