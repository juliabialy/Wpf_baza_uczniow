﻿using System;
using System.Windows;
using System.IO;
using System.Text;
using Microsoft.Win32;
using System.Linq;
using System.Collections.Generic;

namespace uczniowie
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "Pliki CSV (*.csv)|*.csv",
                Title = "Wczytaj plik CSV"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    listaUczniow.Items.Clear();
                    var lines = File.ReadAllLines(openFileDialog.FileName, Encoding.UTF8);

                    foreach (var line in lines.Skip(1))
                    {
                        var columns = line.Split(';');
                        if (columns.Length >= 9)
                        {
                            listaUczniow.Items.Add(new MyItem
                            {
                                Pesel = columns[0],
                                FirstName = columns[1],
                                MiddleName = columns[2],
                                LastName = columns[3],
                                BirthDate = DateTime.Parse(columns[4]),
                                PhoneNumber = columns[5],
                                Address = columns[6],
                                City = columns[7],
                                PostalCode = columns[8]
                            });
                        }
                    }
                    statusText.Text = $"Wczytano {listaUczniow.Items.Count} uczniów";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd wczytywania: {ex.Message}", "Błąd",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var saveFileDialog = new SaveFileDialog
            {
                Filter = "Pliki CSV (*.csv)|*.csv",
                Title = "Zapisz jako plik CSV"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    var lines = new StringBuilder();
                    lines.AppendLine("PESEL;Imię;Drugie imię;Nazwisko;Data urodzenia;Telefon;Adres;Miejscowość;Kod pocztowy");

                    foreach (MyItem item in listaUczniow.Items)
                    {
                        lines.AppendLine(
                            $"{item.Pesel};{item.FirstName};{item.MiddleName};{item.LastName};" +
                            $"{item.BirthDate:yyyy-MM-dd};{item.PhoneNumber};{item.Address};{item.City};{item.PostalCode}"
                        );
                    }

                    File.WriteAllText(saveFileDialog.FileName, lines.ToString(), Encoding.UTF8);
                    statusText.Text = $"Zapisano {listaUczniow.Items.Count} uczniów";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Błąd zapisu: {ex.Message}", "Błąd",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Window1();
            if (dialog.ShowDialog() == true)
            {
                listaUczniow.Items.Add(new MyItem
                {
                    Pesel = dialog.PeselTextBox.Text,
                    FirstName = dialog.NameTextBox.Text,
                    MiddleName = dialog.MiddleNameTextBox.Text,
                    LastName = dialog.SurnameTextBox.Text,
                    BirthDate = dialog.BirthDatePicker.SelectedDate ?? DateTime.Now,
                    PhoneNumber = dialog.PhoneTextBox.Text,
                    Address = dialog.AddressTextBox.Text,
                    City = dialog.CityTextBox.Text,
                    PostalCode = dialog.PostalCodeTextBox.Text
                });
                statusText.Text = "Dodano nowego ucznia";
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (listaUczniow.SelectedItem is MyItem selected)
            {
                var dialog = new Window1(selected);
                if (dialog.ShowDialog() == true)
                {
                    selected.Pesel = dialog.EditedStudent.Pesel;
                    selected.FirstName = dialog.EditedStudent.FirstName;
                    selected.MiddleName = dialog.EditedStudent.MiddleName;
                    selected.LastName = dialog.EditedStudent.LastName;
                    selected.BirthDate = dialog.EditedStudent.BirthDate;
                    selected.PhoneNumber = dialog.EditedStudent.PhoneNumber;
                    selected.Address = dialog.EditedStudent.Address;
                    selected.City = dialog.EditedStudent.City;
                    selected.PostalCode = dialog.EditedStudent.PostalCode;
                    listaUczniow.Items.Refresh();
                    statusText.Text = "Zaktualizowano dane ucznia";
                }
            }
            else
            {
                MessageBox.Show("Wybierz ucznia do edycji", "Błąd",
                               MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (listaUczniow.SelectedItems.Count > 0)
            {
                if (MessageBox.Show("Czy na pewno chcesz usunąć zaznaczonych uczniów?", "Potwierdź",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    var itemsToRemove = listaUczniow.SelectedItems.Cast<MyItem>().ToList();
                    foreach (var item in itemsToRemove)
                    {
                        listaUczniow.Items.Remove(item);
                    }
                    statusText.Text = $"Usunięto {itemsToRemove.Count} uczniów";
                }
            }
            else
            {
                MessageBox.Show("Zaznacz uczniów do usunięcia", "Błąd",
                               MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                "Dziennik uczniów :))\n" +
                "Aplikacja do zarządzania danymi uczniów\n" +
                "Autor: Julia Biały",
                "O programie - Możliwa edycja, dodawanie, usuwanie",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }
}