﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace uczniowie
{
    public static class DataValidator
    {
        public static bool IsValidPesel(string pesel, DateTime? birthDate)
        {
            if (string.IsNullOrEmpty(pesel)) return false;
            if (pesel.Length != 11 || !pesel.All(char.IsDigit)) return false;

            int[] weights = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
            int sum = weights.Select((t, i) => (pesel[i] - '0') * t).Sum();
            int controlDigit = (10 - sum % 10) % 10;
            if (controlDigit != (pesel[10] - '0')) return false;

            int year = int.Parse(pesel.Substring(0, 2));
            int month = int.Parse(pesel.Substring(2, 2));
            int day = int.Parse(pesel.Substring(4, 2));

            if (month >= 80) { year += 1800; month -= 80; }
            else if (month >= 60) { year += 2200; month -= 60; }
            else if (month >= 40) { year += 2100; month -= 40; }
            else if (month >= 20) { year += 2000; month -= 20; }
            else { year += 1900; }

            try
            {
                var parsedDate = new DateTime(year, month, day);
                return birthDate == null || parsedDate.Date == birthDate.Value.Date;
            }
            catch
            {
                return false;
            }
        }

        public static string FormatText(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return input;

            input = Regex.Replace(input.Trim(), @"\s+", " ");
            return System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(input.ToLower());
        }

        public static bool IsValidPostalCode(string postalCode)
        {
            return string.IsNullOrWhiteSpace(postalCode) ||
                   Regex.IsMatch(postalCode, @"^\d{2}-\d{3}$");
        }

        public static string FormatPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber)) return phoneNumber;

            string digits = new string(phoneNumber.Where(char.IsDigit).ToArray());
            if (digits.StartsWith("48") && digits.Length > 2) digits = digits.Substring(2);
            if (digits.Length == 9) return $"+48 {digits.Substring(0, 3)} {digits.Substring(3, 3)} {digits.Substring(6)}";
            return $"+{digits}";
        }

        public static bool IsValidPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber)) return true;
            string digits = new string(phoneNumber.Where(char.IsDigit).ToArray());
            return digits.Length >= 9;
        }
    }
}