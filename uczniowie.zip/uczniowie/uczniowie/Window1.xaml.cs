﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Linq;

namespace uczniowie
{
    public partial class Window1 : Window
    {
        private bool _isPhoneChanging;
        private bool _isFormatting;
        private readonly MyItem _originalStudent;

        public Window1(MyItem studentToEdit = null)
        {
            InitializeComponent();
            _originalStudent = studentToEdit ?? new MyItem();
            InitializeData();
            ValidateForm();
        }

        public MyItem EditedStudent { get; private set; } = new MyItem();

        private void InitializeData()
        {
            PeselTextBox.Text = _originalStudent.Pesel;
            NameTextBox.Text = _originalStudent.FirstName;
            MiddleNameTextBox.Text = _originalStudent.MiddleName;
            SurnameTextBox.Text = _originalStudent.LastName;
            BirthDatePicker.SelectedDate = _originalStudent.BirthDate;
            PhoneTextBox.Text = _originalStudent.PhoneNumber;
            AddressTextBox.Text = _originalStudent.Address;
            CityTextBox.Text = _originalStudent.City;
            PostalCodeTextBox.Text = _originalStudent.PostalCode;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_isFormatting) return;
            ValidateForm();
        }

        private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            ValidateForm();
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (_isFormatting || !(sender is TextBox textBox)) return;

            _isFormatting = true;

            if (textBox == NameTextBox || textBox == MiddleNameTextBox ||
                textBox == SurnameTextBox || textBox == CityTextBox ||
                textBox == AddressTextBox)
            {
                string formatted = DataValidator.FormatText(textBox.Text);
                if (formatted != textBox.Text)
                    textBox.Text = formatted;
            }

            _isFormatting = false;
            ValidateForm();
        }

        private void PostalCode_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!(sender is TextBox textBox)) return;

            string text = new string(textBox.Text.Where(c => char.IsDigit(c) || c == '-').ToArray());
            if (text.Length == 2 && !text.Contains("-"))
                text += "-";
            if (text != textBox.Text)
                textBox.Text = text;

            ValidateForm();
        }

        private void PhoneTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_isPhoneChanging || !(sender is TextBox textBox)) return;

            _isPhoneChanging = true;
            string formatted = DataValidator.FormatPhoneNumber(textBox.Text);
            if (formatted != textBox.Text)
                textBox.Text = formatted;
            _isPhoneChanging = false;

            ValidateForm();
        }

        private void ValidateForm()
        {

            bool isPeselValid = PeselTextBox != null &&
                               DataValidator.IsValidPesel(PeselTextBox.Text, BirthDatePicker?.SelectedDate);

            bool isNameValid = NameTextBox != null &&
                              !string.IsNullOrWhiteSpace(NameTextBox.Text);

            bool isSurnameValid = SurnameTextBox != null &&
                                 !string.IsNullOrWhiteSpace(SurnameTextBox.Text);

            bool isPhoneValid = true;
            if (PhoneTextBox != null)
            {
                isPhoneValid = string.IsNullOrEmpty(PhoneTextBox.Text) ||
                              DataValidator.IsValidPhoneNumber(PhoneTextBox.Text);
            }

            if (PeselTextBox != null)
                PeselTextBox.Background = isPeselValid ? Brushes.White : Brushes.Red;

            if (NameTextBox != null)
                NameTextBox.Background = isNameValid ? Brushes.White : Brushes.Red;

            if (SurnameTextBox != null)
                SurnameTextBox.Background = isSurnameValid ? Brushes.White : Brushes.Red;

            if (PhoneTextBox != null)
                PhoneTextBox.Background = isPhoneValid ? Brushes.White : Brushes.Red;
       
            if (btnSave != null)
            {
                btnSave.IsEnabled = isPeselValid &&
                                   isNameValid &&
                                   isSurnameValid &&
                                   isPhoneValid;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateAllFields()) return;

            EditedStudent = new MyItem
            {
                Pesel = PeselTextBox.Text ?? string.Empty,
                FirstName = NameTextBox.Text ?? string.Empty,
                MiddleName = MiddleNameTextBox.Text ?? string.Empty,
                LastName = SurnameTextBox.Text ?? string.Empty,
                BirthDate = BirthDatePicker.SelectedDate ?? DateTime.Now,
                PhoneNumber = PhoneTextBox.Text ?? string.Empty,
                Address = AddressTextBox.Text ?? string.Empty,
                City = CityTextBox.Text ?? string.Empty,
                PostalCode = PostalCodeTextBox.Text ?? string.Empty
            };

            DialogResult = true;
            Close();
        }

        private bool ValidateAllFields()
        {
            if (!DataValidator.IsValidPesel(PeselTextBox.Text, BirthDatePicker.SelectedDate))
            {
                MessageBox.Show("Nieprawidłowy PESEL!", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!string.IsNullOrEmpty(PhoneTextBox.Text) && !DataValidator.IsValidPhoneNumber(PhoneTextBox.Text))
            {
                MessageBox.Show("Nieprawidłowy numer telefonu!", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }

        private void Anuluj_Click(object sender, RoutedEventArgs e)
        {
            if (CzyDaneZmienione() &&
                MessageBox.Show("Czy na pewno chcesz odrzucić wprowadzone zmiany?", "Potwierdzenie",
                               MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
            {
                return;
            }

            DialogResult = false;
            Close();
        }

        private bool CzyDaneZmienione()
        {
            return PeselTextBox.Text != (_originalStudent.Pesel ?? "") ||
                   NameTextBox.Text != (_originalStudent.FirstName ?? "") ||
                   MiddleNameTextBox.Text != (_originalStudent.MiddleName ?? "") ||
                   SurnameTextBox.Text != (_originalStudent.LastName ?? "") ||
                   BirthDatePicker.SelectedDate != _originalStudent.BirthDate ||
                   PhoneTextBox.Text != (_originalStudent.PhoneNumber ?? "") ||
                   AddressTextBox.Text != (_originalStudent.Address ?? "") ||
                   CityTextBox.Text != (_originalStudent.City ?? "") ||
                   PostalCodeTextBox.Text != (_originalStudent.PostalCode ?? "");
        }
    }
}